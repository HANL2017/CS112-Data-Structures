//Han Lin and Steven Gryszel
package application;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;


import structures.Graph;
import structures.Vertex;


public class Friends {
	
	static Graph graph;
	static BufferedReader buffr;
	
public static void main(String args[]) throws IOException {
	Vertex[] adjlists = null;
	buffr = new BufferedReader(new InputStreamReader(System.in));
	
		
	System.out.print("Enter the name of the graph => ");
	
	while(true){
	try{
		
	String file = buffr.readLine();
	Scanner sc = new Scanner(new File(file));
	
	Graph graph = new Graph(adjlists, sc);
	
	graph.build();
	
	while(true){		
			try{
			System.out.println();
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println(" Menu ");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println();
			
			System.out.println("Choose from the following numbers:");
			System.out.println("(1) for subgraph of chosen school");
			System.out.println("(2) for shortest intro chain");
			System.out.println("(3) for cliques");
			System.out.println("(4) for connectors");
			System.out.println("(5) to quit");
			
			System.out.println();
			System.out.println("Pick a choice => ");
			
			int choice = Integer.parseInt(buffr.readLine());
			
			if(choice > 5 || choice < 1){
				System.out.println();
				System.out.println("Please enter a number 1 - 5");
				System.out.println();
			}
			
			if(choice == 1){
				System.out.println();
				System.out.print("Type in the school you need the subgraph for: ");
				
				Scanner scan = new Scanner(System.in);
				String getschool = scan.nextLine(); 
				Graph subgr = graph.subGraph(getschool);
				subgr.printoutgraph();
				
				continue;
			
			}else if(choice == 2){
				System.out.println("Who is the first person to find in the graph? => ");
				
				Scanner scan = new Scanner(System.in);
				String pers1 = scan.nextLine();
				
				System.out.println("Who is the second person to find in the graph? => ");
				
				String pers2 = scan.nextLine();
				boolean result=graph.shortpath(pers1,pers2);
				
				if(!result){
				System.out.println("A path was not found between those people");
				}
				
				continue;
			
			}else if(choice == 3){
				System.out.println();
				System.out.print("What school do you want to find the cliques for? :  ");
				
				Scanner scan = new Scanner(System.in);
				String school = scan.nextLine(); 
				Graph sub = graph.subGraph(school);
				
				sub.dfscliqs();
				
				continue;
			
			}else if(choice == 4){
				
				graph.connectors();
				
				continue;
			
			}else if(choice == 5){
				return;
			}
			
			}catch(NumberFormatException e){
				
				System.out.println();
				System.out.println("Please enter a number 1 - 5");
				System.out.println();
				
				continue;
				
			}
			
	
		}
	
	}catch(FileNotFoundException e){
		System.out.println();
		System.out.println("File specified not found!");
		System.out.println();
		System.out.println("Enter the name of the graph again below:");
		continue;
	}
		
	}
}

}
