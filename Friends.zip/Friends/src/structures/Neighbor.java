package structures;
public class Neighbor {
	
	public int vertnum;
	public Neighbor next;

	public Neighbor(int vertnum, Neighbor nbr) {
		
		this.vertnum = vertnum;
		this.next = nbr;
	}
}
