package structures;

public class Vertex {
	
	int vertnum;
	Student student;
	Neighbor neighbor;
	boolean visited = false;

	Vertex(Student student, int vertnum, Neighbor neighbor) {
		
		this.vertnum = vertnum;
		this.neighbor = neighbor;
		this.student = student;
		this.visited = false;

	}

	public String toString() {
		
		if (this.student.getSchoolName() != null)
			return (this.student.getName() + "|y|" + this.student.getSchoolName());
		else{
			return (this.student.getName() + "|n");
		}
			
	}
}