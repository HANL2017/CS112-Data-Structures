package structures;

class Student {
	
	private boolean isStudent;
	
	private String School, Name;

	public Student(String name, String isstudent, String school) {
		
		this.School = school;
		this.Name = name;
		
		if (isstudent.equalsIgnoreCase("y")) {
			this.isStudent = true;
		
		} else if(isstudent.equalsIgnoreCase("n")) {
			this.isStudent = false;
		
		}else{
			this.isStudent = false;
		}
	}
	
	public Student(Student a){
		Name = a.Name;
		School = a.School;
	}

	public String getName() {
		return Name;
	}
	
	public String getSchoolName() {
		return School;
	}

	

}
