package structures;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Queue;
import java.util.StringTokenizer;
import java.util.LinkedList;

public class Graph {
	
	Scanner scan;
	Vertex[] adjLists;
	

	public Graph(Vertex[] adlists, Scanner scan) {
		this.adjLists = adlists;
		this.scan = scan;
		
	}
	
	int indexname(String name) {
		for (int v = 0; v < adjLists.length; v++) {
			
			if (adjLists[v].student.getName().equals(name)) {
				
				return v;
			}
		}
		return -1;
	}

	public int getlength() {

		return this.adjLists.length;
	}
	
	public int getsize(Vertex[] list) {

		int count = 0;
		
		for (int i = 0; i < list.length; i++) {
			if (list[i] != null)
				count++;
		}
		return count;
	}
	
	public void printoutgraph() {
		
		System.out.println(getsize(this.adjLists));
		
		for (int i = 0; i < this.adjLists.length; i++) {
			if (this.adjLists[i] != null) {
				System.out.println(this.adjLists[i]);
			}
		}

		for (int i = 0; i < this.adjLists.length; i++) {
			if (this.adjLists[i] != null) {
				Neighbor temp = this.adjLists[i].neighbor;

				while (temp != null) {
					if (this.adjLists[temp.vertnum] != null && temp.vertnum > i) {
						System.out.println(this.adjLists[i].student.getName() + "|" + this.adjLists[temp.vertnum].student.getName());
					}
					temp = temp.next;
				}
			}

		}

	}
	
	public void build() throws FileNotFoundException {
		
		adjLists = new Vertex[Integer.parseInt(scan.nextLine())];
		
		int i = 0;
		
		while (i < adjLists.length) {
			
			String school;
			
			StringTokenizer stringtoke = new StringTokenizer(scan.nextLine(), "|");
			
			String name = stringtoke.nextToken();
			String studentcheck = stringtoke.nextToken();
			

			if (studentcheck.equalsIgnoreCase("y")) {
				school = stringtoke.nextToken();
			
			}else if(studentcheck.equalsIgnoreCase("n")) {
				school = null;
			
			}else{
				school = null;
			}

			Student curr = new Student(name, studentcheck, school);
			
			adjLists[i] = new Vertex(curr, i, null);
			
			i++;
		}

		populateGraph();

	}
	
	private void populateGraph(){
		
		while (scan.hasNext()) {
			
			StringTokenizer stringtoke = new StringTokenizer(scan.nextLine(), "|");
			
			String name1 = stringtoke.nextToken();
			String name2 = stringtoke.nextToken();

			int vert1 = indexname(name1);
			int vert2 = indexname(name2);

			adjLists[vert1].neighbor = new Neighbor(vert2, adjLists[vert1].neighbor);
			
			adjLists[vert2].neighbor = new Neighbor(vert1, adjLists[vert2].neighbor);

		}

	}

	public Graph subGraph(String schoolsub) {

		Vertex[] sub = new Vertex[adjLists.length];

		for (int i = 0; i < sub.length; i++) {
			sub[i] = adjLists[i];
		}
		
		for (int i = 0; i < sub.length; i++) {
			
			if (sub[i].student.getSchoolName() == null || !sub[i].student.getSchoolName().equalsIgnoreCase(schoolsub)) {
				
				sub[i] = null;

			}
		}

		Graph subgraph = new Graph(sub, scan);
		System.out.println();
		return subgraph;
	}

	public void dfscliqs() {

		int cliqcount = 1;
		
		Vertex[] cliqadjlists = new Vertex[this.adjLists.length];
		
		boolean[] visited = new boolean[this.adjLists.length];
		
		for (int i = 0; i < visited.length; i++) {
			
			if (this.adjLists[i] != null) {
				
				visited[i] = false;
			
			} else{
				
				visited[i] = true;
			}
				
		}
		
		System.out.println();
		
		for (int i = 0; i < visited.length; i++) {
			if (!visited[i]) {

				dfs(i, cliqadjlists, visited);

				System.out.println("Clique #: " + cliqcount);
				
				Graph clique = new Graph(cliqadjlists, scan);
				
				System.out.println();
				clique.printoutgraph();
				System.out.println();

				if (adjLists[i] != null && visited[i] == true) {
					
					cliqadjlists = new Vertex[this.adjLists.length];
					cliqcount++;

				}
			}
		}
		
		System.out.println();
	}

	private void dfs(int v,  Vertex[] cliqadjlists, boolean[] visited) {
		
		visited[v] = true;

		cliqadjlists[v] = this.adjLists[v];
		Neighbor nb = this.adjLists[v].neighbor;

		while (nb != null) {
			
			if (!visited[nb.vertnum]) {

				dfs(nb.vertnum, cliqadjlists, visited);
			}
			
			nb = nb.next;
		}
	}

	public void connectors() {
		boolean[] connectors = new boolean[adjLists.length];
		boolean connect = true;
		
		System.out.println();
		
		int i = 0;
		
		System.out.println("Below are the connectors:");
		System.out.println();
		
		while(i < adjLists.length) {
			
			if (adjLists[i].neighbor != null && adjLists[i].neighbor.next == null) {
				
				if (adjLists[adjLists[i].neighbor.vertnum].neighbor.next != null && !connectors[adjLists[i].neighbor.vertnum]) {
					
					
						if (connect) {
							
							System.out.print(adjLists[adjLists[i].neighbor.vertnum].student.getName());
							connectors[adjLists[i].neighbor.vertnum] = true;
							connect = false;	
						
						} else if (!connect) {
							
							System.out.print(", "+ adjLists[adjLists[i].neighbor.vertnum].student.getName());
							connectors[adjLists[i].neighbor.vertnum] = true;
							
						}
					
				}
				
			}
			
			i++;
	
		}
		System.out.println();
	
	}

	
	public boolean shortpath(String name, String name2) {
		
		int vertnum1 = this.indexname(name);
		int vertnum2 = this.indexname(name2);
		
		boolean path = false;
		
		
		if (vertnum1 == -1 || vertnum2 == -1) {
			
			return path;
			
		}
		
		boolean[] flagged = new boolean[this.adjLists.length];
		
		int[] predec = new int[this.adjLists.length];
		
		for (int x = 0; x < this.adjLists.length; x++) {
			
			flagged[x] = false;
			predec[x] = -1;
			
		}
		
		Queue<Vertex> q = new LinkedList<Vertex>();

		flagged[vertnum1] = true;

		q.add(this.adjLists[vertnum1]);
		
		while (!q.isEmpty()) {
			
			Vertex temp = q.remove();
			
			Neighbor tempN = temp.neighbor;
			while (tempN != null) {

				if (tempN.vertnum == vertnum2) {
					predec[vertnum2] = temp.vertnum;
					path = true;
					
					break;
					
				} else if (!flagged[tempN.vertnum] && temp.neighbor.vertnum != vertnum2) {
					
					flagged[tempN.vertnum] = true;
					
					predec[tempN.vertnum] = temp.vertnum;
					
					q.add(this.adjLists[tempN.vertnum]);
					tempN = tempN.next;

				} else {
					tempN = tempN.next;
				}

			}
			
			if (path && predec[vertnum2] != -1)
				break;

		}
		if (path) {
			
			int a = vertnum2;
			
			int count = 0;
			
			String result = "";
			
			while (predec[a] != -1) {
				
				result += adjLists[a].student.getName() + "-";
				a = predec[a];
				count++;
			}
			
			result = result + adjLists[a].student.getName();
			
			String[] finalresult = new String[count + 1];
			
			finalresult = result.split("-");
			
			for (int f = count; f >= 0; f--) {
				if (f == 0) {
					
					System.out.print(finalresult[f]);
					
				} else{
					
					System.out.print(finalresult[f] + "--");
				}
					
			}
		}
		return path;
	}

}
